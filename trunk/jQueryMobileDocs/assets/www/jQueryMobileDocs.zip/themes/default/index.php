<?php
$type = "text/css";
$elements = array(
	'jquery.mobile.theme.css',
	'jquery.mobile.core.css',
	'jquery.mobile.transitions.css',
	'jquery.mobile.grids.css',
	'jquery.mobile.headerfooter.css',
	'jquery.mobile.navbar.css',
	'jquery.mobile.button.css',
	'jquery.mobile.collapsible.css',
	'jquery.mobile.controlgroup.css',
	'jquery.mobile.dialog.css',
	'jquery.mobile.forms.checkboxradio.css',
	'jquery.mobile.forms.fieldcontain.css',
	'jquery.mobile.forms.select.css',
	'jquery.mobile.forms.textinput.css',
	'jquery.mobile.listview.css',
	'jquery.mobile.forms.slider.css'
);

include('../../combine.php');
?>
