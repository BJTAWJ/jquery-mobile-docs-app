<?php
$type = "text/css";
$elements = array(
	'jquery.mobile.theme.css',
	'../default/jquery.mobile.core.css',
	'../default/jquery.mobile.transitions.css',
	'../default/jquery.mobile.grids.css',
	'../default/jquery.mobile.headerfooter.css',
	'../default/jquery.mobile.navbar.css',
	'../default/jquery.mobile.button.css',
	'../default/jquery.mobile.collapsible.css',
	'../default/jquery.mobile.controlgroup.css',
	'../default/jquery.mobile.dialog.css',
	'../default/jquery.mobile.forms.checkboxradio.css',
	'../default/jquery.mobile.forms.fieldcontain.css',
	'../default/jquery.mobile.forms.select.css',
	'../default/jquery.mobile.forms.textinput.css',
	'../default/jquery.mobile.listview.css',
	'../default/jquery.mobile.forms.slider.css'
);

include('../../combine.php');
?>